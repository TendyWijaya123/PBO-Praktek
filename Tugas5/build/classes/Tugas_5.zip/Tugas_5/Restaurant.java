/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_5;

/**
 *
 * @author Lenovo
 */
public class Restaurant {
    private Menu[] menuMakanan = new Menu[10];
    private byte id = 0;

    public void addMakanan(String namaMakanan, double hargaMakanan, int stok) {
        if (id < menuMakanan.length) {
            Menu newItem = new Menu();
            newItem.setNamaMakanan(namaMakanan);
            newItem.setHargaMakanan(hargaMakanan);
            newItem.setStok(stok);
            menuMakanan[id] = newItem;
            id++;
        } else {
            System.out.println("Menu is full. Cannot add more items.");
        }
    }

    public void tampilMenuMakanan() {
        for (byte i = 0; i < id; i++) {
            if (!isOutOfStock(i)) {
                System.out.println(menuMakanan[i].getNamaMakanan() + " [" + menuMakanan[i].getStok() + "] =" + menuMakanan[i].getHargaMakanan());
            }
        }
    }

    public boolean isOutOfStock(byte i) {
        return menuMakanan[i].getStok() == 0;
    }
}

